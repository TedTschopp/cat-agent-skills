---
name: copilot-studio-test-planner
description: |
  Generates a full test plan and eval set for a Microsoft Copilot Studio agent.
  Use when the user asks to "create a test plan for my Copilot Studio agent",
  "generate test cases for an agent", "build an eval set", "write regression
  tests for my agent", "how do I test my agent", or shares an exported agent
  definition, topic YAML, or solution and wants tests to run before shipping.
---

# Copilot Studio Test Planner

Turn a Microsoft Copilot Studio agent into a graded, runnable test suite the
maker can execute in the Copilot Studio test panel before publishing. You
produce tests; you do not modify the maker's tenant.

## Inputs you accept
- An exported solution ZIP, one or more topic YAML files, or pasted agent
  definition text.
- If nothing is attached, ask the maker to export the agent (Copilot Studio >
  the agent > ... > Export, or download the solution) and attach it, or to paste
  the topic YAML. If details are still missing, list what you assumed. Do not
  invent topics, tools, or knowledge that are not in the input.

## Workflow
1. **Inventory the agent.** Identify orchestration mode (classic or generative)
   if discoverable, topics and their triggers or descriptions, tools and actions,
   knowledge sources, connected or child agents, configured languages, and
   authentication mode. State anything you could not determine.
2. **Derive test cases** across these categories:
   - **Happy path**: for every topic and tool, at least one utterance that should
     select it, with the expected topic or tool named.
   - **Paraphrase**: a reworded utterance for each key topic to test robustness
     (especially important for generative selection, which keys off descriptions).
   - **Disambiguation**: utterances that plausibly match two topics, to verify the
     agent asks or routes correctly.
   - **Slot filling**: inputs that force the agent to ask for missing parameters.
   - **Negative / no-match**: off-topic utterances that should fall back to
     knowledge or a graceful "I cannot help with that", not a wrong topic.
   - **Knowledge grounding**: questions the knowledge sources should answer, plus
     one the sources do not cover (to check it does not hallucinate).
   - **Multilingual**: if secondary languages are configured, one utterance per
     language for a core topic.
   - **Safety**: one prompt-injection or out-of-scope attempt to confirm the agent
     stays in role and does not leak instructions.
3. **Assemble a regression set.** Mark the subset (roughly 8 to 12 cases) that
   must pass on every future change.
4. **Emit the output** in the exact format below.
5. **Explain how to run it**: paste each utterance into the Copilot Studio test
   panel (embedded test chat), compare the triggered topic or tool against
   Expected, and record Pass or Fail. Note that the embedded test chat is free of
   billed Copilot Credits.

## Output format
Return exactly these sections.

### 1. Coverage summary
Two or three sentences: how many tests, which topics and tools are covered, and
any part of the agent you could not generate tests for (and why).

### 2. Test matrix
A table with every case:

| ID | Utterance | Expected topic or tool | Category | Notes |
|----|-----------|------------------------|----------|-------|

Use stable IDs (T01, T02, ...). Notes call out what the case proves or any setup
needed (for example a required variable value).

### 3. Regression set
The list of IDs from the matrix that must pass on every change, with a one-line
reason each.

### 4. Edge cases and risks
Short bullets on the riskiest behaviors to watch (disambiguation, no-match
fallback, multilingual, safety), each tied to the test IDs that exercise it.

### 5. How to run
The step-by-step for executing the suite in the Copilot Studio test panel and
recording results, including that test-panel runs do not consume billed Copilot
Credits.

## Rules
- Every test names a concrete expected topic or tool. Never write "should work".
- Do not invent product features, menu paths, limits, or agent contents you were
  not given. If a detail depends on current product behavior, say so and point the
  maker to Microsoft Learn.
- Do not embed secrets or absolute file paths in your output.
- Do not use the em dash character; use a hyphen or rewrite.
